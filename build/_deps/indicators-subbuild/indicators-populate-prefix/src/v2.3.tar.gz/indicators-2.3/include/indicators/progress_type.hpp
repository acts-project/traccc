
#ifndef INDICATORS_PROGRESS_TYPE
#define INDICATORS_PROGRESS_TYPE

namespace indicators {
enum class ProgressType { incremental, decremental };
}

#endif