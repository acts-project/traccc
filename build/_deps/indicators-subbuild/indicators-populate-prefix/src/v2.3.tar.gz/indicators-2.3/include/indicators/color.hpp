
#ifndef INDICATORS_COLOR
#define INDICATORS_COLOR

namespace indicators {
enum class Color { grey, red, green, yellow, blue, magenta, cyan, white, unspecified };
}

#endif
