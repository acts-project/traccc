# Build Recipe for covfie

This directory holds a simple build recipe for the
[covfie](https://github.com/acts-project/covfie) project.
