This directory holds a simple build recipe for the `nlohmann::json` library. Used in case
`DETRAY_USE_SYSTEM_NLOHMANN` is set to `FALSE` for the build.
