# Build Recipe for Algebra Plugins

This directory holds a build recipe for the
[algebra-plugins](https://github.com/acts-project/algebra-plugins) project.
