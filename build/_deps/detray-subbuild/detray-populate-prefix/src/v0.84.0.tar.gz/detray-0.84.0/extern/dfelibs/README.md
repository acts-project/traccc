# Build Recipe for dfelibs

This directory holds a simple build recipe for the
[dfelibs](https://github.com/msmk0/dfelibs) project.
