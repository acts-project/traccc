# Build Recipe for VecMem

This directory holds a simple build recipe for the
[VecMem](https://github.com/acts-project/vecmem) project.
