This directory holds a simple build recipe for the
[ActSVG](https://github.com/acts-project/actsvg) project. Used in case
`DETRAY_USE_SYSTEM_ACTSVG` is set to `FALSE` for the build.
