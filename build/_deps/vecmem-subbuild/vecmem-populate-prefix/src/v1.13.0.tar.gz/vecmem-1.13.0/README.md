# VecMem

VecMem is part of the ACTS project (R&D line for parallelization), the ACTS
project can be found: https://github.com/acts-project/acts.

This project provides a set of base and helper classes to implement a vectorised
data model with. One that can be efficiently used across multiple device types.
