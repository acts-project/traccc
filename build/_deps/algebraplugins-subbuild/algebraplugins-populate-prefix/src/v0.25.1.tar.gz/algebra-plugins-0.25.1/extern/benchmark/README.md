# Build Recipe for Google Benchmark

This directory holds a simple build recipe for the
[Google Benchmark](https://github.com/google/benchmark/) project.
