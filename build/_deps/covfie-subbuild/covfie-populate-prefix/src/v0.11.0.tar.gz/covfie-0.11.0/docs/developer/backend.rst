Backend internals
=================
